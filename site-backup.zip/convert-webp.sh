#!/bin/bash
# ============================================================
# Convert all images to WebP for أمان التركيب
# Requirements: cwebp (libwebp), imagemagick, ffmpeg
# Usage: bash convert-webp.sh
# ============================================================

ASSETS_DIR="/var/www/amaaltarkeb.com/assets"
QUALITY=82  # High quality, small size

echo "Converting images to WebP in $ASSETS_DIR..."

# Create directory for WebP if not exists
mkdir -p "$ASSETS_DIR"

# Convert JPEG/JPG to WebP
for img in "$ASSETS_DIR"/*.{jpg,jpeg,JPG,JPEG}; do
    if [ -f "$img" ]; then
        webp="${img%.*}.webp"
        if [ ! -f "$webp" ] || [ "$img" -nt "$webp" ]; then
            echo "Converting: $img -> $webp"
            cwebp -q $QUALITY -preset photo -m 6 -pass 10 -mt "$img" -o "$webp"
        fi
    fi
done

# Convert PNG to WebP
for img in "$ASSETS_DIR"/*.png; do
    if [ -f "$img" ]; then
        webp="${img%.*}.webp"
        if [ ! -f "$webp" ] || [ "$img" -nt "$webp" ]; then
            echo "Converting: $img -> $webp"
            cwebp -q $QUALITY -preset picture -m 6 -pass 10 -mt "$img" -o "$webp"
        fi
    fi
done

# Create responsive sizes (320w, 640w, 960w, 1200w) for hero images
echo "Creating responsive sizes for hero images..."
HERO_IMAGES=(
    "hik-colorvu-cameras.jpg"
    "solar-dual-ptz-rain.jpg"
    "dahua-fullcolor-mixed.jpg"
)

SIZES=(320 640 960 1200)

for hero in "${HERO_IMAGES[@]}"; do
    img_path="$ASSETS_DIR/$hero"
    if [ -f "$img_path" ]; then
        basename="${hero%.*}"
        for size in "${SIZES[@]}"; do
            out="$ASSETS_DIR/${basename}-${size}w.webp"
            if [ ! -f "$out" ]; then
                echo "Creating: $out"
                cwebp -q $QUALITY -resize $size 0 -preset photo -m 6 -mt "$img_path" -o "$out"
            fi
        done
    fi
done

# Convert to AVIF for even better compression (if avifenc is available)
if command -v avifenc &> /dev/null; then
    echo "Creating AVIF versions..."
    for img in "$ASSETS_DIR"/*.{jpg,jpeg,png}; do
        if [ -f "$img" ]; then
            avif="${img%.*}.avif"
            if [ ! -f "$avif" ]; then
                echo "Converting: $img -> $avif"
                avifenc --speed 6 --quality 60 "$img" "$avif"
            fi
        fi
    done
fi

echo "=== WebP Conversion Complete! ==="
echo "Run this script whenever new images are added."
