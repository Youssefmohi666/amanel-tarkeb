# دليل النشر الآمن — أمان التركيب (amaaltarkeb.com)

## هيكل ملفات المشروع

```
/var/www/amaaltarkeb.com/
├── index.html            ← الصفحة الرئيسية (مُولَّد تلقائياً)
├── about.html            ← صفحة من نحن
├── contact.html          ← صفحة التواصل
├── 404.html              ← صفحة الخطأ
├── robots.txt            ← تعليمات الزواحف
├── sitemap.xml           ← خريطة الموقع (مُولَّدة تلقائياً)
│
├── assets/
│   ├── css/
│   │   ├── main.css      ← نظام تصميم الموقع
│   │   └── admin.css     ← أنماط لوحة التحكم
│   ├── js/
│   │   └── main.js       ← منطق الواجهة المشترك
│   └── uploads/          ← الصور المرفوعة من لوحة التحكم
│
├── data/                 ← قواعد البيانات الفلات (JSON)
│   ├── settings.json
│   ├── products.json
│   └── blogs.json
│
├── templates/            ← قوالب الصفحات الديناميكية
│   ├── index.template.html
│   ├── about.template.html
│   ├── contact.template.html
│   ├── services.template.html
│   ├── service-detail.template.html
│   ├── blog-index.template.html
│   ├── blog.template.html
│   ├── product.template.html
│   └── 404.template.html
│
├── products/             ← صفحات المنتجات (مُولَّدة تلقائياً)
├── services/             ← صفحات الخدمات
├── blog/                 ← مقالات المدونة (مُولَّدة تلقائياً)
│
└── admin/                ← لوحة التحكم (يجب تأمينها)
    ├── config.php        ← إعدادات المصادقة
    ├── save.php          ← API الفلات-فايل
    ├── login.html
    ├── index.html
    ├── products.html
    ├── blogs.html
    └── settings.html
```

---

## 1. متطلبات الخادم

| المتطلب      | الإصدار المطلوب |
|--------------|-----------------|
| PHP          | 8.0 أو أحدث    |
| Nginx        | 1.18+           |
| Linux OS     | Ubuntu 20.04+   |

---

## 2. إعداد Nginx الأساسي

```nginx
server {
    listen 80;
    server_name amaaltarkeb.com www.amaaltarkeb.com;
    root /var/www/amaaltarkeb.com;
    index index.html index.php;
    charset utf-8;

    # إعادة توجيه HTTP إلى HTTPS
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name amaaltarkeb.com www.amaaltarkeb.com;
    root /var/www/amaaltarkeb.com;
    index index.html;
    charset utf-8;

    # شهادة SSL (Let's Encrypt)
    ssl_certificate /etc/letsencrypt/live/amaaltarkeb.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/amaaltarkeb.com/privkey.pem;

    # --- قواعد الأمان الأساسية ---

    # ⛔ منع الوصول المباشر لملفات JSON (قاعدة البيانات)
    location /data/ {
        deny all;
        return 403;
    }

    # ⛔ منع الوصول المباشر لملفات القوالب
    location /templates/ {
        deny all;
        return 403;
    }

    # ⛔ منع الوصول لملفات PHP مباشرة ماعدا save.php
    location ~ \.php$ {
        deny all;
    }

    # ✅ السماح فقط لـ admin/save.php بالتنفيذ
    location = /admin/save.php {
        fastcgi_pass unix:/var/run/php/php8.1-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_param SCRIPT_NAME $fastcgi_script_name;
        include fastcgi_params;
    }

    # ✅ السماح فقط لـ admin/config.php بالتضمين (مُغلق للتنفيذ المباشر)
    location = /admin/config.php {
        deny all;
    }

    # --- رأس الأمان (Security Headers) ---
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Permissions-Policy "camera=(), microphone=(), geolocation=()" always;

    # صفحة الخطأ 404 المخصصة
    error_page 404 /404.html;
    location = /404.html {
        internal;
    }

    # ضغط Gzip للأداء
    gzip on;
    gzip_types text/html text/css application/json application/javascript text/xml;

    location / {
        try_files $uri $uri/ =404;
    }
}
```

---

## 3. تأمين مجلد لوحة التحكم `/admin/` بكلمة مرور إضافية (HTTP Basic Auth)

يُنصح بإضافة طبقة حماية ثانية على مستوى Nginx بكلمة مرور مستقلة عن لوحة PHP:

```bash
# تثبيت أداة htpasswd
sudo apt install apache2-utils -y

# إنشاء ملف المستخدمين
sudo htpasswd -c /etc/nginx/.htpasswd admin_user
# ستُطلب منك كلمة مرور جديدة

# إضافة الكتلة التالية داخل server block في إعداد nginx
```

```nginx
location /admin/ {
    auth_basic "منطقة مقيدة — أمان التركيب";
    auth_basic_user_file /etc/nginx/.htpasswd;

    # السماح لـ save.php فقط بالتنفيذ PHP
    location = /admin/save.php {
        fastcgi_pass unix:/var/run/php/php8.1-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_param SCRIPT_NAME $fastcgi_script_name;
        include fastcgi_params;
        auth_basic "منطقة مقيدة — أمان التركيب";
        auth_basic_user_file /etc/nginx/.htpasswd;
    }
}
```

---

## 4. صلاحيات الملفات على الخادم

```bash
# تعيين مالك الملفات لمستخدم Nginx
sudo chown -R www-data:www-data /var/www/amaaltarkeb.com

# صلاحيات المجلدات
sudo find /var/www/amaaltarkeb.com -type d -exec chmod 755 {} \;

# صلاحيات الملفات
sudo find /var/www/amaaltarkeb.com -type f -exec chmod 644 {} \;

# مجلد data يحتاج صلاحية كتابة من PHP
sudo chmod 755 /var/www/amaaltarkeb.com/data/
sudo chmod 755 /var/www/amaaltarkeb.com/assets/uploads/

# مجلد admin يُضيَّق للقراءة فقط (ماعدا save.php)
sudo chmod 644 /var/www/amaaltarkeb.com/admin/config.php
```

---

## 5. تثبيت SSL بـ Let's Encrypt

```bash
# تثبيت certbot
sudo apt install certbot python3-certbot-nginx -y

# إنشاء شهادة SSL مجانية تلقائية
sudo certbot --nginx -d amaaltarkeb.com -d www.amaaltarkeb.com

# التجديد التلقائي
sudo systemctl enable certbot.timer
sudo crontab -e
# أضف السطر التالي:
# 0 3 * * * certbot renew --quiet
```

---

## 6. تغيير كلمة مرور لوحة التحكم

كلمة المرور الافتراضية: `aman2026`

لتغيير كلمة المرور، نفّذ الكود التالي في PHP وانسخ الـ hash الناتج:

```php
<?php
$new_password = 'كلمة_المرور_الجديدة';
echo password_hash($new_password, PASSWORD_BCRYPT, ['cost' => 10]);
```

ثم افتح ملف `/admin/config.php` وحدث قيمة الـ hash داخل مصفوفة `$ADMIN_USERS`.

---

## 7. تحديث المحتوى بعد النشر

عند رفع ملفات المشروع لأول مرة، شغّل مرة واحدة فقط سكريبت إعادة توليد الصفحات من لوحة التحكم:

1. اذهب إلى `https://amaaltarkeb.com/admin/login.html`
2. سجّل الدخول بكلمة المرور
3. من الرئيسية اضغط **"إعادة توليد صفحات الموقع"**

أو شغّل مباشرة من سطر أوامر الخادم:
```bash
cd /var/www/amaaltarkeb.com
php -r "
  \$_SESSION = ['admin_user' => 'admin'];
  \$_GET['action'] = 'regenerate_all';
  // Run via cli — for one-time deployment only
"
```

---

## 8. ملاحظات أمنية هامة

> ⚠️ **تحذيرات مهمة قبل النشر:**
> 1. **غيّر** كلمة المرور الافتراضية `aman2026` فوراً بعد أول تسجيل دخول
> 2. **أضف** طبقة HTTP Basic Auth على `/admin/` لحماية مزدوجة
> 3. **تحقق** من أن مجلد `/data/` محجوب تماماً في إعدادات Nginx
> 4. **فعّل** HTTPS قبل أي استخدام للنظام في بيئة الإنتاج
> 5. **احتفظ** بنسخ احتياطية يومية من مجلد `/data/*.json`
> 6. **لا ترفع** ملف `admin/config.php` لأي مستودع Git عام

---

*developed by dev-core.site*