document.addEventListener('DOMContentLoaded', () => {
  // Mobile Hamburger Menu
  const hamburger = document.getElementById('hamburger');
  const mobileMenu = document.getElementById('mobileMenu');
  const mobileOverlay = document.getElementById('mobileOverlay');
  const mobileClose = document.getElementById('mobileClose');

  function toggleMobileMenu() {
    mobileMenu.classList.toggle('open');
    mobileOverlay.classList.toggle('open');
  }

  if (hamburger) hamburger.addEventListener('click', toggleMobileMenu);
  if (mobileClose) mobileClose.addEventListener('click', toggleMobileMenu);
  if (mobileOverlay) mobileOverlay.addEventListener('click', toggleMobileMenu);

  // Close mobile menu on clicking any link
  const mobileLinks = document.querySelectorAll('.mobile-menu-links a');
  mobileLinks.forEach(link => {
    link.addEventListener('click', () => {
      mobileMenu.classList.remove('open');
      mobileOverlay.classList.remove('open');
    });
  });

  // Sticky Navigation Header on Scroll
  const mainNav = document.querySelector('.main-nav');
  if (mainNav) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 40) {
        mainNav.style.padding = '5px 0';
        mainNav.style.boxShadow = '0 10px 30px rgba(0,0,0,0.3)';
        mainNav.style.background = 'rgba(10, 15, 30, 0.95)';
      } else {
        mainNav.style.padding = '0';
        mainNav.style.boxShadow = 'none';
        mainNav.style.background = 'rgba(10, 15, 30, 0.85)';
      }
    });
  }

  // Active Link Highlighter based on window URL
  const currentPath = window.location.pathname;
  const navLinks = document.querySelectorAll('.nav-menu a, .mobile-menu-links a');
  navLinks.forEach(link => {
    const href = link.getAttribute('href');
    if (href === currentPath || (href === '/' && currentPath === '/index.html')) {
      link.classList.add('active');
    }
  });

  // Dynamic FAQs Accordion Toggle
  const faqCards = document.querySelectorAll('.faq-card');
  faqCards.forEach(card => {
    const trigger = card.querySelector('.faq-trigger');
    if (trigger) {
      trigger.addEventListener('click', () => {
        const isOpen = card.hasAttribute('open');
        // Close all other details cards
        faqCards.forEach(c => {
          if (c !== card) c.removeAttribute('open');
        });
        if (isOpen) {
          card.removeAttribute('open');
        } else {
          card.setAttribute('open', '');
        }
      });
    }
  });

  // Product Tabs Filtering
  const tabButtons = document.querySelectorAll('.tab-btn');
  const productCards = document.querySelectorAll('.product-card');

  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      tabButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filter = btn.dataset.filter;
      productCards.forEach(card => {
        if (filter === 'all' || card.dataset.category === filter) {
          card.style.display = 'flex';
          card.style.opacity = '0';
          setTimeout(() => {
            card.style.transition = 'opacity 0.3s ease';
            card.style.opacity = '1';
          }, 50);
        } else {
          card.style.display = 'none';
        }
      });
    });
  });

  // Hero Auto-Slider
  const slider = document.querySelector('.hero-slider');
  if (slider) {
    const slides = document.querySelectorAll('.hero-slide');
    let currentIndex = 0;
    const slideInterval = 5000; // 5 seconds

    function nextSlide() {
      currentIndex = (currentIndex + 1) % slides.length;
      slider.style.transform = `translateX(${currentIndex * 100}%)`;
    }

    if (slides.length > 1) {
      setInterval(nextSlide, slideInterval);
    }
  }
});
