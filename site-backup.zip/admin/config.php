<?php
// Prevents direct access
if (count(get_included_files()) === 1) {
    http_response_code(403);
    exit('Forbidden');
}

// Session security setup
if (session_status() === PHP_SESSION_NONE) {
    // Session lifetime: 2 hours (7200 seconds)
    ini_set('session.gc_maxlifetime', 7200);
    ini_set('session.cookie_lifetime', 7200);
    
    // Cookie security flags
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    
    // Set secure flag if https is present
    if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
        ini_set('session.cookie_secure', 1);
    }
    
    session_start();
}

// Session expiration validator
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 7200)) {
    session_unset();
    session_destroy();
    session_start();
}
$_SESSION['LAST_ACTIVITY'] = time();

// Authorized Users List
// Default password: 'admin' => 'aman2026'
$ADMIN_USERS = [
    'admin' => '$2y$10$iM.oG9J7Lg80U10WskGvbeZ4h4d.K/rWkM4Kq6t3sP/LixJ16wFvO' // bcrypt hash of 'aman2026'
];
?>
