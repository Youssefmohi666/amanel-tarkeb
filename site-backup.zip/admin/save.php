<?php
// Include security configuration & sessions
require_once __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');

// Helper response functions
function sendError($message, $code = 400) {
    http_response_code($code);
    echo json_encode(['status' => 'error', 'message' => $message]);
    exit;
}

function sendSuccess($data = []) {
    echo json_encode(array_merge(['status' => 'success'], $data));
    exit;
}

// 1. Auth check endpoint / login processing
$action = $_GET['action'] ?? '';

if ($action === 'login') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        sendError('Method not allowed', 405);
    }
    
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        sendError('يرجى إدخال اسم المستخدم وكلمة المرور');
    }
    
    if (isset($ADMIN_USERS[$username]) && password_verify($password, $ADMIN_USERS[$username])) {
        $_SESSION['admin_user'] = $username;
        $_SESSION['LAST_ACTIVITY'] = time();
        sendSuccess(['message' => 'تم تسجيل الدخول بنجاح']);
    } else {
        sendError('اسم المستخدم أو كلمة المرور غير صحيحة');
    }
}

// Check authorization for all other actions
if (!isset($_SESSION['admin_user'])) {
    sendError('Unauthorized access', 401);
}

if ($action === 'logout') {
    session_unset();
    session_destroy();
    sendSuccess(['message' => 'تم تسجيل الخروج بنجاح']);
}

// Database JSON file paths
$settings_file = __DIR__ . '/../data/settings.json';
$products_file = __DIR__ . '/../data/products.json';
$blogs_file = __DIR__ . '/../data/blogs.json';

// Helper to secure dynamic folder creations
function ensure_directory($path) {
    if (!file_exists($path)) {
        mkdir($path, 0755, true);
    }
}

// Core compilation functions
function get_settings() {
    global $settings_file;
    if (!file_exists($settings_file)) {
        return [];
    }
    return json_decode(file_get_contents($settings_file), true) ?: [];
}

function get_products() {
    global $products_file;
    if (!file_exists($products_file)) {
        return [];
    }
    return json_decode(file_get_contents($products_file), true) ?: [];
}

function get_blogs() {
    global $blogs_file;
    if (!file_exists($blogs_file)) {
        return [];
    }
    return json_decode(file_get_contents($blogs_file), true) ?: [];
}

// Full site static regeneration
function regenerate_all_pages() {
    $settings = get_settings();
    $products = get_products();
    $blogs = get_blogs();

    // ── Master SEO keyword string ──────────────────────────────────────────
    // Core viral phrases requested by the business owner
    $master_keywords = 'امان التركيب, أمان التركيب, صيانه, صيانه الدش المركزي, الدش المركزي, محل بيع كاميرات, كاميرات مراقبه, كاميرات مراقبه في المدينه المنوره, تركيب كاميرات, عقود صيانه, كاميرات مراقبة, كاميرات مراقبة المدينة المنورة, تركيب كاميرات مراقبة, عقود صيانة معتمدة, Hikvision, Dahua, Cudy, Zyxel, ColorVu, Full-Color, Mesh WiFi, 5G Router, CCTV المدينة المنورة';
    // Add every product name dynamically
    $product_names_kw = implode(', ', array_column($products, 'name'));
    // Merge with admin-configured keywords from settings
    $settings_kw = trim($settings['meta_keywords'] ?? '');
    $seo_keywords = $master_keywords
        . (strlen($product_names_kw) ? ', ' . $product_names_kw : '')
        . (strlen($settings_kw)      ? ', ' . $settings_kw      : '');

    // Map common variables
    $vars = [
        '{{SITE_NAME}}'        => htmlspecialchars($settings['site_name'] ?? ''),
        '{{SITE_TITLE}}'       => htmlspecialchars($settings['site_title'] ?? ''),
        '{{SITE_DESCRIPTION}}' => htmlspecialchars($settings['site_description'] ?? ''),
        '{{META_KEYWORDS}}'    => htmlspecialchars($settings['meta_keywords'] ?? ''),
        '{{SEO_KEYWORDS}}'     => htmlspecialchars($seo_keywords),
        '{{PHONE}}'            => htmlspecialchars($settings['phone'] ?? ''),
        '{{WHATSAPP}}'         => htmlspecialchars($settings['whatsapp'] ?? ''),
        '{{WORK_HOURS}}'       => htmlspecialchars($settings['work_hours'] ?? ''),
        '{{LOCATION}}'         => htmlspecialchars($settings['location'] ?? ''),
        '{{MAP_COORDS}}'       => $settings['map_coords'] ?? '',
        '{{FOOTER_TEXT}}'      => htmlspecialchars($settings['footer_text'] ?? ''),
    ];

    // Apply basic variable replacement to a string
    $replace_vars = function($content) use ($vars) {
        return str_replace(array_keys($vars), array_values($vars), $content);
    };

    // 1. Regenerate Main Static Pages from Templates
    $templates_dir = __DIR__ . '/../templates';
    
    // ── FAQPage JSON-LD (AEO) — Homepage ────────────────────────────────────
    $homepage_faq_ld = json_encode([
        '@context' => 'https://schema.org',
        '@type'    => 'FAQPage',
        'mainEntity' => [
            ['@type'=>'Question','name'=>'ما هي خدمات أمان التركيب في المدينة المنورة؟','acceptedAnswer'=>['@type'=>'Answer','text'=>'تقدم أمان التركيب تركيب كاميرات المراقبة من هيكفيجن وداهوا، تقوية شبكات Mesh WiFi، وعقود صيانة الدش المركزي والكاميرات المعتمدة لدى البلدية والأمن العام.']],
            ['@type'=>'Question','name'=>'هل توفرون عقود صيانة معتمدة للمحلات التجارية؟','acceptedAnswer'=>['@type'=>'Answer','text'=>'نعم، نوفر عقود صيانة سنوية ودورية معتمدة لتجديد تراخيص المحلات والمنشآت وفق اشتراطات الدفاع المدني والبلدية والأمن العام.']],
            ['@type'=>'Question','name'=>'كيف أطلب تركيب كاميرات مراقبة في المدينة المنورة؟','acceptedAnswer'=>['@type'=>'Answer','text'=>'تواصل معنا عبر واتساب للرد الفوري أو اتصل بنا مباشرة لطلب كشف مجاني وعرض سعر لتركيب كاميرات المراقبة في منزلك أو محلك.']],
            ['@type'=>'Question','name'=>'ما الفرق بين كاميرات ColorVu وكاميرات Full-Color؟','acceptedAnswer'=>['@type'=>'Answer','text'=>'كاميرات ColorVu من هيكفيجن وكاميرات Full-Color من داهوا توفران رؤية ليلية ملونة 24/7 بدلاً من الأبيض والأسود، للتعرف على الألوان والتفاصيل ليلاً بوضوح كامل.']],
            ['@type'=>'Question','name'=>'هل تعملون على صيانة الدش المركزي؟','acceptedAnswer'=>['@type'=>'Answer','text'=>'نعم، نقدم صيانة الدش المركزي وإصلاح الأعطال وتجديد العقود المعتمدة في المدينة المنورة والمناطق المجاورة.']],
        ]
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

    // index.html
    if (file_exists($templates_dir . '/index.template.html')) {
        $index_html = file_get_contents($templates_dir . '/index.template.html');
        $index_html = $replace_vars($index_html);
        // Inject FAQPage AEO schema
        $index_html = str_replace('</head>', "\n  <script type=\"application/ld+json\">\n  {$homepage_faq_ld}\n  </script>\n</head>", $index_html);
        
        // Populate products cards inside homepage template
        $products_list_html = '';
        foreach ($products as $p) {
            $cat = htmlspecialchars($p['category']);
            $slug = htmlspecialchars($p['slug']);
            $name = htmlspecialchars($p['name']);
            $desc = htmlspecialchars($p['short_description']);
            $img = htmlspecialchars($p['image']);
            $brand = htmlspecialchars($p['brand']);
            
            $specs_html = '';
            if (isset($p['specs']) && is_array($p['specs'])) {
                $specs_html .= '<ul class="product-specs-preview">';
                $i = 0;
                foreach ($p['specs'] as $k => $v) {
                    if ($i++ >= 3) break; // show top 3 specs only
                    $specs_html .= '<li><strong>' . htmlspecialchars($k) . ':</strong> ' . htmlspecialchars($v) . '</li>';
                }
                $specs_html .= '</ul>';
            }
            
            $products_list_html .= '
            <div class="product-card" data-category="' . $cat . '">
              <div class="product-img-wrap">
                <img src="' . $img . '" alt="' . $name . '" loading="lazy">
                <span class="product-info-badge">' . ($cat === 'cameras' ? 'كاميرات مراقبة' : 'أجهزة شبكات') . '</span>
              </div>
              <div class="product-card-body">
                <span class="product-brand">' . $brand . '</span>
                <h3>' . $name . '</h3>
                <p class="product-short-desc">' . $desc . '</p>
                ' . $specs_html . '
              </div>
              <div class="product-card-footer">
                <a href="products/' . $slug . '.html" class="product-btn-detail">تفاصيل المنتج</a>
                <a href="https://wa.me/' . $vars['{{WHATSAPP}}'] . '?text=مرحباً، أود الاستفسار عن تركيب: ' . $name . '" class="product-btn-whatsapp" target="_blank" rel="noopener noreferrer">
                  <i class="ti ti-brand-whatsapp"></i> تواصل للسعر
                </a>
              </div>
            </div>';
        }
        $index_html = str_replace('{{PRODUCTS_SHOWCASE_LIST}}', $products_list_html, $index_html);
        file_put_contents(__DIR__ . '/../index.html', $index_html);
    }

    // about.html
    if (file_exists($templates_dir . '/about.template.html')) {
        $about_html = file_get_contents($templates_dir . '/about.template.html');
        $about_html = $replace_vars($about_html);
        file_put_contents(__DIR__ . '/../about.html', $about_html);
    }

    // contact.html
    if (file_exists($templates_dir . '/contact.template.html')) {
        $contact_html = file_get_contents($templates_dir . '/contact.template.html');
        $contact_html = $replace_vars($contact_html);
        // Inject Contact FAQPage AEO schema
        $contact_faq_ld = json_encode([
            '@context' => 'https://schema.org',
            '@type'    => 'FAQPage',
            'mainEntity' => [
                ['@type'=>'Question','name'=>'كيف يمكنني التواصل مع أمان التركيب؟','acceptedAnswer'=>['@type'=>'Answer','text'=>'تواصل معنا عبر واتساب للرد الفوري، أو الاتصال برقم هاتفنا مباشرة، أو زيارة معرضنا بالمدينة المنورة خلال أوقات العمل.']],
                ['@type'=>'Question','name'=>'هل تقدمون كشفاً فنياً مجانياً قبل التركيب؟','acceptedAnswer'=>['@type'=>'Answer','text'=>'نعم، نوفر كشفاً فنياً مجانياً لتقييم احتياجاتك وتقديم عرض سعر مناسب لتركيب الكاميرات أو تقوية الشبكة أو عقد الصيانة.']],
                ['@type'=>'Question','name'=>'ما هي مناطق تغطية خدماتكم؟','acceptedAnswer'=>['@type'=>'Answer','text'=>'نخدم المدينة المنورة وجميع أحياءها وضواحيها. تواصل معنا للتأكد من تغطية منطقتك والحصول على موعد.']],
            ]
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        $contact_html = str_replace('</head>', "\n  <script type=\"application/ld+json\">\n  {$contact_faq_ld}\n  </script>\n</head>", $contact_html);
        file_put_contents(__DIR__ . '/../contact.html', $contact_html);
    }

    // 404.html
    if (file_exists($templates_dir . '/404.template.html')) {
        $error_html = file_get_contents($templates_dir . '/404.template.html');
        $error_html = $replace_vars($error_html);
        file_put_contents(__DIR__ . '/../404.html', $error_html);
    }

    // services/index.html
    ensure_directory(__DIR__ . '/../services');
    if (file_exists($templates_dir . '/services.template.html')) {
        $services_html = file_get_contents($templates_dir . '/services.template.html');
        $services_html = $replace_vars($services_html);
        file_put_contents(__DIR__ . '/../services/index.html', $services_html);
    }

    // services individual pages
    $services_list = [
        'camera-installation' => [
            'title' => 'تركيب كاميرات المراقبة المعتمدة',
            'desc' => 'نقدم خدمة تركيب كاميرات المراقبة للمنازل والمنشآت التجارية والشركات بالمدينة المنورة بأعلى معايير الأمان المعتمدة.',
            'features' => '<li><strong>فريق فني معتمد:</strong> تركيب احترافي خالي من العيوب للأسلاك والتمديدات.</li>
                           <li><strong>كاميرات ملونة بالكامل:</strong> نوفر كاميرات ملونة 24 ساعة بدقة 5 ميجابكسل و 8 ميجابكسل.</li>
                           <li><strong>ربط فوري بالجوال:</strong> إمكانية مراقبة محلك أو منزلك من أي مكان بالعالم وعبر الجوال.</li>
                           <li><strong>عقود صيانة رسمية:</strong> نلتزم بتوفير عقود صيانة معتمدة تناسب اللوائح الأمنية للبلدية والأمن العام.</li>',
            'image' => 'assets/hik-colorvu-cameras.jpg'
        ],
        'network-strengthening' => [
            'title' => 'حلول تقوية شبكات الواي فاي وتمديدها',
            'desc' => 'هل تعاني من انقطاع الإنترنت أو ضعف الواي فاي في غرف منزلك؟ نوفر حلولاً جذرية لتقوية التغطية وتمديد شبكات الألياف البصرية.',
            'features' => '<li><strong>تقنية WiFi Mesh المتداخلة:</strong> تركيب أحدث أنظمة الـ Mesh لتغطية المنزل بالكامل بشبكة واي فاي واحدة موحدة وسريعة.</li>
                           <li><strong>أجهزة راوتر 5G المتطورة:</strong> توفير راوترات استقبال تدعم الجيل الخامس وبث WiFi 6 فائق السرعة.</li>
                           <li><strong>تمديد شبكات داخلية سلكية:</strong> تمديد كابلات شبكة CAT6/CAT7 عالية السرعة للشاشات وأجهزة الألعاب والمكاتب.</li>
                           <li><strong>استقرار تام دون انقطاع:</strong> وداعاً للمناطق الميتة أو بطء وسائط الاتصال مع أجهزة معتمدة من Cudy و Zyxel.</li>',
            'image' => 'assets/cudy-m1300.jpg'
        ],
        'maintenance' => [
            'title' => 'عقود صيانة كاميرات المراقبة المعتمدة',
            'desc' => 'نوفر عقود صيانة دورية ووقائية معتمدة لتجديد التراخيص للمحلات والمنشآت التجارية في المدينة المنورة وفقاً للاشتراطات الأمنية.',
            'features' => '<li><strong>عقود صيانة معتمدة رسمياً:</strong> إصدار شهادات وعقود معتمدة لتجديد تراخيص البلدية والدفاع المدني.</li>
                           <li><strong>صيانة وقائية دورية:</strong> تنظيف العدسات، فحص وحدات التخزين والمحولات وتحديث الأنظمة لمنع الأعطال.</li>
                           <li><strong>استجابة سريعة للأعطال:</strong> زيارات طارئة لحل مشاكل الكاميرات، التسجيل، أو انقطاع البث بالجوال.</li>
                           <li><strong>ضمان شامل للقطع والخدمة:</strong> نوفر قطع غيار أصلية من Hikvision و Dahua بأسعار معتمدة وضمان دوري.</li>',
            'image' => 'assets/dahua-fullcolor-cams.jpg'
        ]
    ];

    if (file_exists($templates_dir . '/service-detail.template.html')) {
        foreach ($services_list as $s_slug => $s_data) {
            $s_html = file_get_contents($templates_dir . '/service-detail.template.html');
            $s_html = $replace_vars($s_html);
            $s_html = str_replace([
                '{{SERVICE_TITLE}}',
                '{{SERVICE_DESC}}',
                '{{SERVICE_FEATURES}}',
                '{{SERVICE_IMAGE}}',
                '{{SERVICE_SLUG}}'
            ], [
                htmlspecialchars($s_data['title']),
                htmlspecialchars($s_data['desc']),
                $s_data['features'],
                htmlspecialchars($s_data['image']),
                $s_slug
            ], $s_html);
            file_put_contents(__DIR__ . '/../services/' . $s_slug . '.html', $s_html);
        }
    }

    // 2. Regenerate blog/index.html (Articles feed list)
    if (file_exists($templates_dir . '/blog-index.template.html')) {
        $blog_index_html = file_get_contents($templates_dir . '/blog-index.template.html');
        $blog_index_html = $replace_vars($blog_index_html);
        
        $blogs_feed_html = '';
        foreach ($blogs as $b) {
            $title = htmlspecialchars($b['title']);
            $slug = htmlspecialchars($b['slug']);
            $date = htmlspecialchars($b['date']);
            $cat = htmlspecialchars($b['category']);
            $excerpt = htmlspecialchars($b['excerpt']);
            $img = htmlspecialchars($b['image']);
            
            $blogs_feed_html .= '
            <article class="blog-card">
              <div class="blog-card-img">
                <img src="../' . $img . '" alt="' . $title . '" loading="lazy">
              </div>
              <div class="blog-card-body">
                <div class="blog-meta">
                  <span><i class="ti ti-calendar"></i> ' . $date . '</span>
                  <span><i class="ti ti-tag"></i> ' . $cat . '</span>
                </div>
                <h3>' . $title . '</h3>
                <p>' . $excerpt . '</p>
              </div>
              <div class="blog-card-footer">
                <a href="' . $slug . '.html" class="blog-read-more">اقرأ المقال كاملة ←</a>
              </div>
            </article>';
        }
        $blog_index_html = str_replace('{{BLOGS_FEED_LIST}}', $blogs_feed_html, $blog_index_html);
        ensure_directory(__DIR__ . '/../blog');
        file_put_contents(__DIR__ . '/../blog/index.html', $blog_index_html);
    }

    // 3. Regenerate individual products static pages
    ensure_directory(__DIR__ . '/../products');
    if (file_exists($templates_dir . '/product.template.html')) {
        foreach ($products as $p) {
            $p_html = file_get_contents($templates_dir . '/product.template.html');
            $p_html = $replace_vars($p_html);

            // Populate specifications rows
            $specs_table_html = '';
            if (isset($p['specs']) && is_array($p['specs'])) {
                foreach ($p['specs'] as $k => $v) {
                    $specs_table_html .= '<tr><th>' . htmlspecialchars($k) . '</th><td>' . htmlspecialchars($v) . '</td></tr>';
                }
            }

            // Populate features check list
            $features_list_html = '';
            if (isset($p['features']) && is_array($p['features'])) {
                foreach ($p['features'] as $f) {
                    $features_list_html .= '<li>' . htmlspecialchars($f) . '</li>';
                }
            }

            // Generate Structured Data (JSON-LD Product Schema)
            $product_url = 'https://amaaltarkeb.com/products/' . htmlspecialchars($p['slug']) . '.html';
            $p_keywords = $p['name'] . ', ' . $p['brand'] . ', كاميرات مراقبة المدينة المنورة, تركيب كاميرات, امان التركيب, عقود صيانة, ' . implode(', ', array_slice($p['features'] ?? [], 0, 3));
            $json_ld = [
                "@context"    => "https://schema.org",
                "@type"       => "Product",
                "name"        => $p['name'],
                "image"       => "https://amaaltarkeb.com/" . $p['image'],
                "description" => $p['short_description'],
                "keywords"    => $p_keywords,
                "brand" => [
                    "@type" => "Brand",
                    "name"  => $p['brand']
                ],
                "offers" => [
                    "@type"        => "Offer",
                    "url"          => $product_url,
                    "priceCurrency"=> "SAR",
                    "availability" => "https://schema.org/InStock",
                    "seller"       => ["@type" => "Organization", "name" => "أمان التركيب"],
                    "description"  => "تواصل معنا مباشرة عبر واتساب للحصول على سعر وتركيب معتمد"
                ]
            ];

            $p_html = str_replace([
                '{{PRODUCT_NAME}}',
                '{{PRODUCT_BRAND}}',
                '{{PRODUCT_IMAGE}}',
                '{{PRODUCT_SHORT_DESC}}',
                '{{PRODUCT_DESC}}',
                '{{PRODUCT_SPECS_TABLE}}',
                '{{PRODUCT_FEATURES_LIST}}',
                '{{PRODUCT_CANONICAL}}',
                '{{PRODUCT_JSON_LD}}'
            ], [
                htmlspecialchars($p['name']),
                htmlspecialchars($p['brand']),
                htmlspecialchars($p['image']),
                htmlspecialchars($p['short_description']),
                nl2br(htmlspecialchars($p['description'])),
                $specs_table_html,
                $features_list_html,
                $product_url,
                json_encode($json_ld, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)
            ], $p_html);

            file_put_contents(__DIR__ . '/../products/' . htmlspecialchars($p['slug']) . '.html', $p_html);
        }
    }

    // 4. Regenerate individual blog posts static pages
    if (file_exists($templates_dir . '/blog.template.html')) {
        foreach ($blogs as $b) {
            $b_html = file_get_contents($templates_dir . '/blog.template.html');
            $b_html = $replace_vars($b_html);

            // Generate Structured Data (JSON-LD BlogPosting Schema)
            $blog_url = 'https://amaaltarkeb.com/blog/' . htmlspecialchars($b['slug']) . '.html';
            $b_keywords = $b['title'] . ', ' . $b['category'] . ', كاميرات مراقبة المدينة المنورة, تركيب كاميرات, امان التركيب, عقود صيانة, صيانه الدش المركزي';
            $json_ld = [
                "@context" => "https://schema.org",
                "@type"    => "BlogPosting",
                "mainEntityOfPage" => [
                    "@type" => "WebPage",
                    "@id"   => $blog_url
                ],
                "headline"      => $b['title'],
                "description"   => $b['excerpt'],
                "keywords"      => $b_keywords,
                "image"         => "https://amaaltarkeb.com/" . $b['image'],
                "datePublished" => $b['date'],
                "dateModified"  => $b['date'],
                "author" => [
                    "@type" => "Organization",
                    "name"  => $settings['site_name'] ?? 'أمان التركيب'
                ],
                "publisher" => [
                    "@type" => "Organization",
                    "name"  => $settings['site_name'] ?? 'أمان التركيب',
                    "logo"  => [
                        "@type" => "ImageObject",
                        "url"   => "https://amaaltarkeb.com/assets/favicon.svg"
                    ]
                ]
            ];

            $b_html = str_replace([
                '{{BLOG_TITLE}}',
                '{{BLOG_DATE}}',
                '{{BLOG_CATEGORY}}',
                '{{BLOG_IMAGE}}',
                '{{BLOG_CONTENT}}',
                '{{BLOG_EXCERPT}}',
                '{{BLOG_CANONICAL}}',
                '{{BLOG_JSON_LD}}'
            ], [
                htmlspecialchars($b['title']),
                htmlspecialchars($b['date']),
                htmlspecialchars($b['category']),
                htmlspecialchars($b['image']),
                $b['content'], // Raw HTML permitted from editor
                htmlspecialchars($b['excerpt']),
                $blog_url,
                json_encode($json_ld, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)
            ], $b_html);

            file_put_contents(__DIR__ . '/../blog/' . htmlspecialchars($b['slug']) . '.html', $b_html);
        }
    }

    // 5. Auto-Regenerate XML sitemap
    regenerate_sitemap();
}

// Sitemap Generator Logic
function regenerate_sitemap() {
    $products = get_products();
    $blogs    = get_blogs();
    $today    = date('Y-m-d');

    $xml  = '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL;
    $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . PHP_EOL;

    // Static pages with individually tuned priorities
    $static_urls = [
        'https://amaaltarkeb.com/'                                     => ['1.0',  'daily'],
        'https://amaaltarkeb.com/services/camera-installation.html'   => ['0.95', 'weekly'],
        'https://amaaltarkeb.com/services/maintenance.html'           => ['0.95', 'weekly'],
        'https://amaaltarkeb.com/contact.html'                        => ['0.90', 'weekly'],
        'https://amaaltarkeb.com/services/'                           => ['0.85', 'weekly'],
        'https://amaaltarkeb.com/services/network-strengthening.html' => ['0.85', 'weekly'],
        'https://amaaltarkeb.com/blog/'                               => ['0.80', 'weekly'],
        'https://amaaltarkeb.com/about.html'                          => ['0.65', 'monthly'],
    ];

    foreach ($static_urls as $url => [$priority, $changefreq]) {
        $xml .= '  <url>' . PHP_EOL;
        $xml .= '    <loc>' . $url . '</loc>' . PHP_EOL;
        $xml .= '    <lastmod>' . $today . '</lastmod>' . PHP_EOL;
        $xml .= '    <changefreq>' . $changefreq . '</changefreq>' . PHP_EOL;
        $xml .= '    <priority>' . $priority . '</priority>' . PHP_EOL;
        $xml .= '  </url>' . PHP_EOL;
    }

    // Products – high commercial-intent pages get 0.9
    foreach ($products as $p) {
        $xml .= '  <url>' . PHP_EOL;
        $xml .= '    <loc>https://amaaltarkeb.com/products/' . htmlspecialchars($p['slug']) . '.html</loc>' . PHP_EOL;
        $xml .= '    <lastmod>' . $today . '</lastmod>' . PHP_EOL;
        $xml .= '    <changefreq>weekly</changefreq>' . PHP_EOL;
        $xml .= '    <priority>0.90</priority>' . PHP_EOL;
        $xml .= '  </url>' . PHP_EOL;
    }

    // Blog posts – informational pages at 0.70
    foreach ($blogs as $b) {
        $xml .= '  <url>' . PHP_EOL;
        $xml .= '    <loc>https://amaaltarkeb.com/blog/' . htmlspecialchars($b['slug']) . '.html</loc>' . PHP_EOL;
        $xml .= '    <lastmod>' . (isset($b['date']) ? $b['date'] : $today) . '</lastmod>' . PHP_EOL;
        $xml .= '    <changefreq>monthly</changefreq>' . PHP_EOL;
        $xml .= '    <priority>0.70</priority>' . PHP_EOL;
        $xml .= '  </url>' . PHP_EOL;
    }

    $xml .= '</urlset>';
    file_put_contents(__DIR__ . '/../sitemap.xml', $xml);
}

// 2. CMS API Handler
if ($action === 'get_data') {
    $type = $_GET['type'] ?? '';
    if ($type === 'settings') {
        sendSuccess(['data' => get_settings()]);
    } elseif ($type === 'products') {
        sendSuccess(['data' => get_products()]);
    } elseif ($type === 'blogs') {
        sendSuccess(['data' => get_blogs()]);
    } else {
        sendError('Invalid type');
    }
}

if ($action === 'save_settings') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') sendError('Method not allowed', 405);
    
    $settings = [
      "site_name"        => $_POST['site_name'] ?? '',
      "site_title"       => $_POST['site_title'] ?? '',
      "site_description" => $_POST['site_description'] ?? '',
      "phone"            => $_POST['phone'] ?? '',
      "whatsapp"         => $_POST['whatsapp'] ?? '',
      "work_hours"       => $_POST['work_hours'] ?? '',
      "location"         => $_POST['location'] ?? '',
      "map_coords"       => $_POST['map_coords'] ?? '',
      "meta_keywords"    => $_POST['meta_keywords'] ?? '',
      "footer_text"      => $_POST['footer_text'] ?? ''
    ];
    
    file_put_contents($settings_file, json_encode($settings, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    regenerate_all_pages();
    sendSuccess(['message' => 'تم حفظ الإعدادات وتحديث صفحات الموقع بنجاح']);
}

if ($action === 'save_product') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') sendError('Method not allowed', 405);
    
    $slug = $_POST['slug'] ?? '';
    if (empty($slug)) sendError('الاسم اللطيف (Slug) مطلوب');
    
    $products = get_products();
    $found_index = -1;
    foreach ($products as $idx => $p) {
        if ($p['slug'] === $slug) {
            $found_index = $idx;
            break;
        }
    }

    $specs = [];
    if (isset($_POST['spec_keys']) && is_array($_POST['spec_keys'])) {
        foreach ($_POST['spec_keys'] as $idx => $k) {
            $v = $_POST['spec_vals'][$idx] ?? '';
            if (!empty($k)) {
                $specs[$k] = $v;
            }
        }
    }

    $features = [];
    if (isset($_POST['features']) && is_array($_POST['features'])) {
        foreach ($_POST['features'] as $f) {
            if (!empty(trim($f))) {
                $features[] = trim($f);
            }
        }
    }

    $product_data = [
        "slug"              => $slug,
        "name"              => $_POST['name'] ?? '',
        "category"          => $_POST['category'] ?? 'cameras',
        "brand"             => $_POST['brand'] ?? '',
        "image"             => $_POST['image'] ?? 'assets/uploads/default-product.jpg',
        "short_description" => $_POST['short_description'] ?? '',
        "description"       => $_POST['description'] ?? '',
        "features"          => $features,
        "specs"             => $specs
    ];

    if ($found_index !== -1) {
        $products[$found_index] = $product_data;
    } else {
        $products[] = $product_data;
    }

    file_put_contents($products_file, json_encode($products, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    regenerate_all_pages();
    sendSuccess(['message' => 'تم حفظ المنتج وتوليد صفحة المعاينة وتحديث خرائط الموقع']);
}

if ($action === 'delete_product') {
    $slug = $_GET['slug'] ?? '';
    if (empty($slug)) sendError('معرف المنتج مطلوب');
    
    $products = get_products();
    $filtered = [];
    foreach ($products as $p) {
        if ($p['slug'] !== $slug) {
            $filtered[] = $p;
        } else {
            // Delete dynamic page file
            $file = __DIR__ . '/../products/' . $slug . '.html';
            if (file_exists($file)) unlink($file);
        }
    }
    
    file_put_contents($products_file, json_encode($filtered, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    regenerate_all_pages();
    sendSuccess(['message' => 'تم حذف المنتج بنجاح وتحديث الموقع']);
}

if ($action === 'save_blog') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') sendError('Method not allowed', 405);
    
    $slug = $_POST['slug'] ?? '';
    if (empty($slug)) sendError('الاسم اللطيف (Slug) مطلوب');
    
    $blogs = get_blogs();
    $found_index = -1;
    foreach ($blogs as $idx => $b) {
        if ($b['slug'] === $slug) {
            $found_index = $idx;
            break;
        }
    }

    $blog_data = [
        "slug"     => $slug,
        "title"    => $_POST['title'] ?? '',
        "category" => $_POST['category'] ?? 'عام',
        "date"     => $_POST['date'] ?? date('Y-m-d'),
        "image"    => $_POST['image'] ?? 'assets/uploads/default-blog.jpg',
        "excerpt"  => $_POST['excerpt'] ?? '',
        "content"  => $_POST['content'] ?? ''
    ];

    if ($found_index !== -1) {
        $blogs[$found_index] = $blog_data;
    } else {
        $blogs[] = $blog_data;
    }

    file_put_contents($blogs_file, json_encode($blogs, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    regenerate_all_pages();
    sendSuccess(['message' => 'تم حفظ المقال وتوليد صفحة المعاينة وتحديث خرائط الموقع']);
}

if ($action === 'delete_blog') {
    $slug = $_GET['slug'] ?? '';
    if (empty($slug)) sendError('معرف المقال مطلوب');
    
    $blogs = get_blogs();
    $filtered = [];
    foreach ($blogs as $b) {
        if ($b['slug'] !== $slug) {
            $filtered[] = $b;
        } else {
            // Delete dynamic page file
            $file = __DIR__ . '/../blog/' . $slug . '.html';
            if (file_exists($file)) unlink($file);
        }
    }
    
    file_put_contents($blogs_file, json_encode($filtered, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    regenerate_all_pages();
    sendSuccess(['message' => 'تم حذف المقال بنجاح وتحديث الموقع']);
}

if ($action === 'upload_image') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') sendError('Method not allowed', 405);
    if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        sendError('فشل رفع الملف أو لم يتم اختيار ملف');
    }

    $upload_dir = __DIR__ . '/../assets/uploads/';
    ensure_directory($upload_dir);

    $file_info = pathinfo($_FILES['image']['name']);
    $ext = strtolower($file_info['extension'] ?? '');
    
    // Allowed extensions check
    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif'])) {
        sendError('تنسيق الملف غير مسموح به. يجب رفع صور فقط (jpg, png, webp, gif)');
    }

    // Generate custom name
    $new_name = 'upload_' . uniqid() . '.' . $ext;
    $target_file = $upload_dir . $new_name;

    if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
        sendSuccess([
            'message' => 'تم رفع الصورة بنجاح',
            'url' => 'assets/uploads/' . $new_name
        ]);
    } else {
        sendError('حدث خطأ أثناء نقل الملف المرفوع');
    }
}

if ($action === 'regenerate_all') {
    regenerate_all_pages();
    sendSuccess(['message' => 'تمت إعادة توليد كافة صفحات الموقع بنجاح']);
}

sendError('Unknown action requested');
?>
